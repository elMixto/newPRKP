from pathlib import Path

REMOTE_SOLVER_HOST = "http://192.168.18.187:8001"

MLH_MODEL = Path("/home/mixto/repositories/newPRKP/src/solvers/MLHeu/model_data/finalized_model_rTrees.sav")