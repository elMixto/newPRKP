# Basic working code for MLHeu
Add configs in the folder and modify MLHeu.py to set the item-fixing policy.
